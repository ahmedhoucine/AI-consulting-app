import { AlerteComponent } from './alerte.component'

describe('AlerteComponent', () => {
  it('should mount', () => {
    cy.mount(AlerteComponent)
  })
})