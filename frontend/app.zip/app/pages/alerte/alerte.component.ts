import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Alerte {
  id: number;
  nom_prenom: string;
  statut_consultant: string;
  nbr_jrs_inactifs: number;
  date_derniere_mission: string | null;
  competences_principales: string;
  remarque: string;
  vue: boolean;
}

@Component({
  selector: 'app-alerte',
  templateUrl: './alerte.component.html',
})
export class AlerteComponent implements OnInit {
  alertes: Alerte[] = [];
  loading = false;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.chargerAlertes();
  }

  chargerAlertes() {
    this.http.get<Alerte[]>('http://localhost:5000//api/alerte/alertes').subscribe(data => {
      this.alertes = data;
    });
  }

  marquerVue(alerte: Alerte) {
    this.http.post(`http://localhost:5000//api/alerte/${alerte.id}/vue`, {}).subscribe(() => {
      alerte.vue = true;
    });
  }

  supprimerAlerte(alerte: Alerte) {
    if (!confirm("Supprimer cette alerte ?")) return;
    this.http.delete(`http://localhost:5000//api/alerte/${alerte.id}/delete`).subscribe(() => {
      this.alertes = this.alertes.filter(a => a.id !== alerte.id);
    });
  }
}
