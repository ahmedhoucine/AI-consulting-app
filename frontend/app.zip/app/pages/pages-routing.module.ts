import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardsComponent } from './dashboards/dashboards.component';
import { MatchingComponent } from './matching/matching.component';
import { AlerteComponent } from './alerte/alerte.component';
import { RecommendationComponent } from './recommendation/recommendation.component';



const routes: Routes = [
  {
    path: 'tables',
    loadChildren: () => import('./tables/tables.module').then(m => m.TablesModule)
  },
  { path: 'dashboard', component: DashboardsComponent },
  { path: 'matching', component: MatchingComponent },
  {path :'alerte', component:AlerteComponent},
  {path:'recommendation',component:RecommendationComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
