import { RecommendationComponent } from './recommendation.component'

describe('RecommendationComponent', () => {
  it('should mount', () => {
    cy.mount(RecommendationComponent)
  })
})