
import { Component, OnInit } from '@angular/core';
import { RecommendationService } from 'src/app/core/services/recommendation';

@Component({
  selector: 'app-recommendation',
  templateUrl: './recommendation.component.html'
})
export class RecommendationComponent implements OnInit {
  consultants: any[] = [];
  selectedConsultantId: number | null = null;
  recommendations: any[] = [];
  loading = false;

  constructor(private recommendationService: RecommendationService) {}

  ngOnInit() {
    this.recommendationService.getConsultants().subscribe(data => {
      this.consultants = data;
    });
  }

  onConsultantChange() {
    if (this.selectedConsultantId) {
      this.loading = true;
      this.recommendationService.getRecommendations(this.selectedConsultantId)
        .subscribe(data => {
          this.recommendations = data;
          this.loading = false;
        });
    }
  }
}
