import { DashboardsComponent } from './dashboards.component'

describe('DashboardsComponent', () => {
  it('should mount', () => {
    cy.mount(DashboardsComponent)
  })
})