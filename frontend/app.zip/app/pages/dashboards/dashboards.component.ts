import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/core/services/dashboard';

@Component({
  selector: 'app-dashboards',
  templateUrl: './dashboards.component.html'
})
export class DashboardsComponent implements OnInit {
  dashboardData: any;
  totalConsultants: number = 0;

  topJobs: any;
  topSkills: any;
  topSectors: any;

  consultantChartData: any;

  constructor(private dashboardService: DashboardService) {}

  ngOnInit(): void {
    this.dashboardService.getDashboardData().subscribe(data => {
      this.dashboardData = data;

      this.totalConsultants = data.consultant_status.disponible +
                              data.consultant_status.en_mission +
                              data.consultant_status.inactif;

      this.topJobs = {
        title: 'Top Jobs',
        labels: data.top_jobs.map((x: any) => x.nom),
        values: data.top_jobs.map((x: any) => x.occurences)
      };

      this.topSkills = {
        title: 'Top Compétences',
        labels: data.top_skills.map((x: any) => x.nom),
        values: data.top_skills.map((x: any) => x.occurences)
      };

      this.topSectors = {
        title: 'Top Secteurs',
        labels: data.top_secteurs.map((x: any) => x.nom),
        values: data.top_secteurs.map((x: any) => x.occurences)
      };

      this.consultantChartData = {
        series: [
          data.consultant_status.disponible,
          data.consultant_status.en_mission,
          data.consultant_status.inactif
        ],
        chart: { type: 'donut', height: 300 },
        labels: ['Disponible', 'En mission', 'Inactif'],
        colors: ['#34c38f', '#556ee6', '#f46a6a']
      };
    });
  }
}