import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-matching',
  templateUrl: './matching.component.html',
})
export class MatchingComponent implements OnInit {
  consultants: any[] = [];
  missions: any[] = [];
  selectedConsultant: number | null = null;
  selectedMission: number | null = null;

  recommandation: any = null;
  loading = false;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<any>('http://localhost:5000/api/matching/data').subscribe(data => {
      console.log('Données reçues:', data);
      this.consultants = data.consultants;
      this.missions = data.missions;
    });
  }

  genererConseil(): void {
    if (!this.selectedConsultant || !this.selectedMission) return;

    this.loading = true;
    this.recommandation = null;

    this.http.post<any>('http://localhost:5000/api/matching/generer', {
      consultant_id: this.selectedConsultant,
      mission_id: this.selectedMission
    }).subscribe(result => {
      this.recommandation = result;
      this.loading = false;
    });
  }
}
