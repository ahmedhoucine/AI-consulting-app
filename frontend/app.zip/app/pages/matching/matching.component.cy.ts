import { MatchingComponent } from './matching.component'

describe('MatchingComponent', () => {
  it('should mount', () => {
    cy.mount(MatchingComponent)
  })
})