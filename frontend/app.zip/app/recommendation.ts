import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class RecommendationService {
  constructor(private http: HttpClient) {}

  getRecommendations(consultantId: number): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:5000/api/recommendation/${consultantId}`);
  }

  // Simule une API pour récupérer les consultants (à remplacer par ton vrai endpoint si tu en as un)
  getConsultants(): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:5000/api/recommendation/consultants`);  // ou hardcodé si pas encore dispo
  }
}